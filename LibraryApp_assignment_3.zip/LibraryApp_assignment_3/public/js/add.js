let title = document.getElementById("title");
let author = document.getElementById("author");
let genre = document.getElementById("genre");
let img = document.getElementById("img");
let errorTitle = document.getElementById("errorTitle");
let errorAuthor = document.getElementById("errorAuthor");
let errorGenre = document.getElementById("errorGenre");
let errorImg = document.getElementById("errorImg");

function validate(){
    if(title.value == ""){
        errorTitle.innerHTML = "Title Should not be Empty";
        errorTitle.style.color = "red";
        errorTitle.style.fontSize = "smaller";
        return false;
    }
    else if(author.value == ""){
        errorAuthor.innerHTML = "Authors name is Reguired";
        errorAuthor.style.color = "red";
        errorAuthor.style.fontSize = "smaller";
        return false;
    }
    else if(genre.value == ""){
        errorGenre.innerHTML = "Genre should not be Empty";
        errorGenre.style.color = "red";
        errorGenre.style.fontSize = "smaller";
        return false;
    }
    else if(img.value == ""){
        errorImg.innerHTML = "Picture is required";
        errorImg.style.color = "red";
        errorImg.style.fontSize = "smaller";
        return false;
    }
    else{
        errorTitle.innerHTML ="";
        errorAuthor.innerHTML ="";
        errorGenre.innerHTML ="";
        errorImg.innerHTML ="";
        return true;
    }
}