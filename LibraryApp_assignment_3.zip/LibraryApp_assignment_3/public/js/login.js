let mail = document.getElementById("mail");
let pwd = document.getElementById("pwd");
let errorMail = document.getElementById("errorMail");
let errorPwd = document.getElementById("errorPwd");
let strengthBar = document.getElementById("strength");
let strengthTxt = document.getElementById("strengthTxt");

let mailRegex = /^([A-Za-z0-9\.-]+)@([A-Za-z0-9\-]+)\.([a-z]{2,3})(\.[a-z{2,3}])?$/ ;
// let pwdRegex ;

function validate(){
    return ((verifyMail()) && (verifyPassword()));
    
    }

function verifyMail(){
    if(mail.value == ""){
        errorMail.innerHTML = "Email id should not be blank";
        errorMail.style.color = "red";
        errorMail.style.fontSize = "smaller";
        return false;
    }
    else if(mailRegex.test(mail.value) == false){
        errorMail.innerHTML = "Email id is Invalid";
        errorMail.style.color = "red";
        errorMail.style.fontSize = "smaller";
        return false;
    }
     
    else{
        errorMail.innerHTML ="";
        return true;
    }
}

function verifyPassword(){
    // 
    if(pwd.value == ""){
        strengthTxt.innerHTML = "Password is mandatory";
        strengthTxt.style.color = "red";
        strengthTxt.style.fontSize = "smaller";
        return false;
    } 
    var pwdRegex1 = /[a-zA-Z0-9]+/;
    var pwdRegex2 = /[~+()]/;
    var pwdRegex3 = /[@!#$%^&*]/;
    var strength = 0;
    
    if(pwd.value.match(pwdRegex1)){
        strength += 1;
    }
    if(pwd.value.match(pwdRegex2)){
        strength += 1;
    }
    if(pwd.value.match(pwdRegex3)){
        strength += 1;
    }
    if(pwd.value.length > 8){
        strength += 1;
    }
    switch(strength){
        case 0:
            strengthBar.value = 0;
            // alert("hi");
            break;
        
        case 1:
            strengthBar.value = 20;
            strengthBar.innerHTML =" weak";
            strengthBar.style.color ="red";
            break;

        case 2:
            strengthBar.value = 40;
            strengthBar.innerHTML =" good";
            strengthBar.style.color ="orange";
            break;

        case 3:
            strengthBar.value = 60;
            strengthBar.innerHTML =" strong";
            strengthBar.style.color ="green";
            break;

        case 4:
            strengthBar.value = 80;
            strengthBar.innerHTML =" very strong";
            strengthBar.style.color ="darkgreen";
            break;
    }
}
