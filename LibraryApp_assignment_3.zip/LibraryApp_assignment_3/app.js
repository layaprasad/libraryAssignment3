
const express = require('express');
const app = new express();

const nav = [
    {link:'/books',name:'Books'},
    {link:'/authors',name:'Authors'},
    {link:'/admin',name:'Add Books'},
    {link:'/adminAuthor',name:'Add Authors'}
    ];

const booksRouter = require('./src/routes/bookRoutes')(nav);
const authorRoutes = require('./src/routes/authorRoutes')(nav);
const loginRoutes = require('./src/routes/loginRoutes')(nav);
const signupRoutes = require('./src/routes/signupRoutes')(nav);
const adminRouter = require('./src/routes/adminRoutes')(nav);
const adminAuthorRouter = require('./src/routes/adminAuthorRoutes')(nav);

app.use(express.urlencoded({extended:true}));
app.use(express.static('./public'));
app.set('view engine', 'ejs');
app.set('views','./src/views');
app.use('/books',booksRouter);
app.use('/authors',authorRoutes);
app.use('/login',loginRoutes);
app.use('/signup',signupRoutes);
app.use('/admin',adminRouter);
app.use('/adminAuthor',adminAuthorRouter);

var main = [
    {
        title : "Know about the western classic culture",
        author : "Jane Austen",
        genre : "Western Classic",
        img: "jane.jpg"
    },
    {
        title : "Undesirable or Frightening society of ancient greek , The Dystopia ",
        author : "George Orwell",
        genre : "Dystopia",
        img: "george.jpg"
    },
    {
        title : "The books that bring you to an imaginary Universe",
        author : "J.R.R Tolkien",
        genre : "Fantasy",
        img: "tolkien.jpg"
    },
    {
        title : " I do not fear computers. I fear the lack of them !!!!!",
        author : "Issac Asimov",
        genre : "Science Fiction",
        img: "issac.jpg"
    },
    {
        title : "Fiction is the lie through which we tell the truth",
        author : "Suzanne Collins",
        genre : "Fiction",
        img: "suzanne.jpg"
    },
    {
        title : "Speaking through the Experience",
        author : "Jhumpa Lahiri",
        genre : "Immigrant Experience",
        img: "jhumpa.jpg"
    }

];
app.get('/', function(req,res){
    res.render("main",
    {    
        title:'Read Dots Library',   
    });
});

app.get('/index', function(req,res){
    res.render("index",
    {
        nav,
        title:'Read Dots Library',
        main
    });
});

app.listen(5000);
