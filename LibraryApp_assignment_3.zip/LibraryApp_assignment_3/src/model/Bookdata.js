
const mongoose = require('mongoose');    //Accessing mongoose package

mongoose.connect('mongodb://localhost:27017/library');    //Database connection
                            
const Schema = mongoose.Schema;   //schema definition
const bookSchema = new Schema({
    title: String,
    author: String,
    genre: String,
    image: String
});

var bookData = mongoose.model('bookdata',bookSchema);  //model creation and collection name :bookdata

module.exports = bookData;
