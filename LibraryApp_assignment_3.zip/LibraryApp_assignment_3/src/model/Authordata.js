
const mongoose = require('mongoose');  //Accessing mongoose package

mongoose.connect('mongodb://localhost:27017/library'); //create database connection with mongodb
      
const Schema = mongoose.Schema;   //Schema definition
const authorSchema = new Schema({
        author: String,   
        penname: String,
        genre: String,   
        image: String
    });
 
var authorData = mongoose.model('authordata',authorSchema);   //convert schema to a model

module.exports = authorData;

