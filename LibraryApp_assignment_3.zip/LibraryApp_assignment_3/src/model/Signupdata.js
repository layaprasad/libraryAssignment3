
const mongoose = require('mongoose');   

mongoose.connect('mongodb://localhost:27017/library');    
                            
const Schema = mongoose.Schema;   
const signupSchema = new Schema({
    username: String,
    mobile: Number,
    email: String,
    password: String,
    confirmpassword: String
});
var User = mongoose.model('userdata',signupSchema);  

module.exports = User;
