
const express = require('express');

const authorRouter = express.Router();
const AuthorData = require('../model/Authordata');
function router(nav){

    authorRouter.get('/', function(req,res){
        AuthorData.find()
        .then(function(authors){
            res.render("authors",
            {
                nav,
                title:'Library' ,
                authors
            });
        })
        
    });
    authorRouter.get('/:id', function(req,res){
        const id = req.params.id;
        AuthorData.findOne({_id: id})
        .then(function(author){
            res.render('author',
            {
                nav,
                title:'Books' ,
                author 
            });
        });        
    });
    
    authorRouter.get('/:id/delete', function(req,res){   
        const id = req.params.id;
        AuthorData.findOneAndDelete({_id: id})
        .then(function(author){
            res.redirect('/authors');
    });        
});
    authorRouter.get('/:id/update', function(req,res){   
        const id = req.params.id;
        AuthorData.findOne({_id: id})
        .then(function(author){
            res.render('editAuthor',
            {
            nav,
            title:'Update Author' ,
            author
        });
        
    });        
});
    authorRouter.post('/:id/update',function(req,res){
    const id = req.params.id;
    AuthorData.findByIdAndUpdate({_id: id},{$set:{ 
            author: req.body.author,
            penname: req.body.penname,
            genre: req.body.genre,
            image: req.body.image }
        })
        .then(function(author){
            res.redirect('/authors');          
    });   
});

    return authorRouter;
}
module.exports = router;





 






   
// authorRouter.post('/update',function(req,res){
//         const id = req.params.id;
//         var item = {
//             title: req.body.title,
//             author: req.body.author,
//             genre: req.body.genre,
//             image: req.body.image
//         };
//         var book = Bookdata(item);
//         book.save();
            
//         Bookdata.findByIdAndUpdate({_id: id})
//         .then(function(book){
//             res.redirect('/books');

//         });
        
//     });









