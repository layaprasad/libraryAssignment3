
const express = require('express');
const signupRouter = express.Router();
const User = require('../model/Signupdata');

function router(nav){
    
    signupRouter.get('/', function(req,res){
        
        res.render("signup",
        {
            nav,
            title:'Sign Up' 
        });
    });
    signupRouter.post('/add',function(req,res){    
        var item = {
                username: req.body.username,
                mobile: req.body.mobile,
                email: req.body.email,
                password: req.body.password,
                confirmpassword: req.body.confirmpassword
        };
        
       var signup =  User(item);
       signup.save();                //saving to the db
       res.redirect('/login');    
    
    });
    return signupRouter;
}

module.exports = router;











