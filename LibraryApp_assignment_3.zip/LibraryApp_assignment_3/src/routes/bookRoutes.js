
const express = require('express');

const booksRouter = express.Router();
const Bookdata = require('../model/Bookdata');
function router(nav){

    booksRouter.get('/', function(req,res){
        Bookdata.find()
        .then(function(books){
            res.render("books",
            {
                nav,
                title:'Library' ,
                books
            });
        })
        
    });
    
    booksRouter.get('/:id', function(req,res){
        const id = req.params.id;
        Bookdata.findOne({_id: id})
        .then(function(book){
        res.render('book',
        {
            nav,
            title:'Books' ,
            book 
        });
        });        
    });
    booksRouter.get('/:id/delete', function(req,res){   
        const id = req.params.id;
        Bookdata.findOneAndDelete({_id: id})
        .then(function(book){
            res.redirect('/books');
    });        
});
    booksRouter.get('/:id/update', function(req,res){   
        const id = req.params.id;
        Bookdata.findOne({_id: id})
        .then(function(book){
            res.render('update',
            {
            nav,
            title:'Books' ,
            book
        });
        
    });        
});
   
    booksRouter.post('/:id/update',function(req,res){
        const id = req.params.id;
        Bookdata.findByIdAndUpdate({_id: id},
            {$set:{ 
                title: req.body.title,
                author: req.body.author,
                genre: req.body.genre,
                image: req.body.image
            }
        })   
        .then(function(book){
        res.redirect('/books');                 
    });       
});
   
    return booksRouter;
}

module.exports = router;











