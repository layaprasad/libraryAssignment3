
const express = require('express');
const adminAuthorRouter = express.Router();
const authorData = require('../model/Authordata');

function router(nav){
    adminAuthorRouter.get('/',function(req,res){
        res.render('addAuthor',{
            nav,
            title:'Add Author' ,           
        })
    });
    adminAuthorRouter.post('/add',function(req,res){   
        var item = {           
            author: req.body.author,
            penname: req.body.penname,
            genre: req.body.genre,
            image: req.body.image
        };   
        var author = authorData(item);   
        author.save();   //saving to database
        res.redirect('/authors');
    });
    return adminAuthorRouter;
}

   module.exports = router;