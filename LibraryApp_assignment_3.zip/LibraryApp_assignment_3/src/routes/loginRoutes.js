
const express = require('express');
const loginRoutes = express.Router();
// const login = require('../model/Logindata');
const User = require('../model/Signupdata');


function router(nav){
 
    loginRoutes.get('/', function(req,res){   
        res.render("login",
        {
            nav,
            title:'Library'            
        }); 
    });
 
    loginRoutes.post('/data',function(req,res){   
            var email = req.body.email;
            var password =  req.body.password;
            
        User.findOne({email:req.body.email, password:req.body.password} , function(err, user){
                if(err){
                    console.log(err);
                    return res.status(500).send();
                }
                if(!user){
                    res.redirect('/');
                    return res.status(404).send();
                }
                res.redirect("/index");
                return res.status(200).send();
           })                
    }); 
   
    return loginRoutes;
}
module.exports = router;









